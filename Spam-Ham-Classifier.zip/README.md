# Spam/Ham Message Classifier

A Python project to classify messages as **spam** or **ham (legitimate)** using **Machine Learning**.

## Tech Stack
- Python
- Pandas
- Scikit-learn
- TF-IDF Vectorizer
- Logistic Regression

## Dataset
Sample dataset is included in `data/messages.csv`.  
Columns:
- `label` → 'spam' or 'ham'
- `message` → the text message

## How to Run
1. Clone the repository:
```bash
git clone https://github.com/yourusername/Spam-Ham-Classifier.git
```
2. Install dependencies:
```bash
pip install -r requirements.txt
```
3. Run the classifier:
```bash
python spam_ham_classifier.py
```
4. Enter a message to test if it's spam or ham.

## Sample Output
```
Enter a message: Congratulations! You won a prize!
Prediction: spam

Enter a message: Are we meeting tomorrow?
Prediction: ham
```

## Learning Outcomes
- Text preprocessing using **TF-IDF**
- Building ML models for **classification**
- Evaluating models with **accuracy and classification reports**
- Making interactive Python programs
